import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.rms.*;

public class RMS extends MIDlet {

 // nombre de la BD
 static final String BD = "datos";

 String dato;
 int id, i;
 char b;
        
    public RMS() {

        RecordStore rs = null;

        // Borramos la BD si ten�a algo
        try {
            RecordStore.deleteRecordStore(BD);
        } catch( Exception e ){}

        try {
	        // Abrimos el recordStore
            rs = RecordStore.openRecordStore(BD, true);

 			guardaRegistro(rs,"Datos del registro 1");
 			guardaRegistro(rs,"Datos del registro 2");
 			guardaRegistro(rs,"Datos del registro 3");

            // Leemos los registros
            RecordEnumeration registros = rs.enumerateRecords(null, null, false);
	        	
	       // Recorremos todos los elementos
	       while (registros.hasNextElement()) {

	        	// Obtenemos el ID del siguiente registro
	      		verRegistro(rs, registros.nextRecordId());
			}     
			       
	        rs.closeRecordStore();
	        
		} catch( RecordStoreException e ){
           	System.out.println( e );
        }
            
                
        notifyDestroyed();
    }
   
    public void verRegistro(RecordStore rs, int id) {
	    
	    try {
     		ByteArrayInputStream bais = new ByteArrayInputStream(rs.getRecord(id));
			DataInputStream is = new DataInputStream(bais);   
		      	
      		// leemos el registro
			try {
	    		dato = is.readUTF();
				System.out.println("-> "+dato);
       		} catch (EOFException eofe) {
   			} catch (IOException ioe) {}
   		} catch (RecordStoreException e) {}
    }
    
    
    
    public void guardaRegistro(RecordStore rs, String dato) {
		
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream os = new DataOutputStream(baos);
		
		try {
			// guadar el dato
	    	os.writeUTF(dato);
		} catch (IOException ioe) {}

		// extraer el array de butes
		byte[] b = baos.toByteArray();

		// lo a�adimos al recordStore
		try {
		    rs.addRecord(b, 0, b.length);
		} catch (RecordStoreException rse) {} 	  
    }
    
    
    public void destroyApp( boolean unconditional ) {}

    public void startApp() {}

    public void pauseApp() {}
}
