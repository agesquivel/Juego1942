import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Canvas2 extends MIDlet implements CommandListener {

 private Command exitCommand;
 private Display display;
 private SSCanvas screen;

 public Canvas2() {
	display=Display.getDisplay(this);
	exitCommand = new Command("Salir",Command.SCREEN,2);

	screen=new SSCanvas();
	screen.addCommand(exitCommand);
	screen.setCommandListener(this);
 }
 
 public void startApp() throws MIDletStateChangeException {
	display.setCurrent(screen);
 }

 public void pauseApp() {}

 public void destroyApp(boolean unconditional) {}

 public void commandAction(Command c, Displayable s) {

	if (c == exitCommand) {
		destroyApp(false);
		notifyDestroyed();
	}

 }
 
}

class SSCanvas extends Canvas {

 public void paint(Graphics g) {

	 Image img=null;
	 
	// Borrar la pantalla
	g.setColor(255,255,255);
	g.fillRect (0, 0, getWidth(), getHeight());

	// Dibujar l�nea
	g.setColor(10,200,100);
    g.drawLine (0, 80, getWidth(), 80);
    	
    // Poner texto
	Font fuente = Font.getFont (Font.FACE_PROPORTIONAL, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
	g.setFont(fuente);
    
	g.drawString("J2ME", getWidth()/2, 10,Graphics.BASELINE|Graphics.HCENTER);
	
	// Cargar y mostrar gr�fico
	try {
		img = Image.createImage("/logo.png");
	} catch (Exception e) {
		System.err.println("error: " + e);
	}

	g.drawImage (img, getWidth()/2, 40, Graphics.HCENTER|Graphics.VCENTER);
	
 }
}
