import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;
import java.io.*;

 public class Sonido extends MIDlet implements CommandListener {
	private Display display; 
	private Form formulario; 
	private Command exit; 
	private Command wav, nota, secuencia; 
	
	
	public Sonido() {

		display = Display.getDisplay(this);

		exit = new Command("Salir", Command.EXIT, 1);
		wav = new Command("WAV", Command.SCREEN, 2);
		nota = new Command("Nota", Command.SCREEN, 2);
		secuencia = new Command("Secuencia", Command.SCREEN, 2);
	
		formulario = new Form("Reproducir.");
		formulario.addCommand(exit);
		formulario.addCommand(wav);
		formulario.addCommand(nota);
		formulario.addCommand(secuencia);
		formulario.setCommandListener(this);
 }
 
 
 public void startApp() {
	display.setCurrent(formulario);
 }
 
 public void pauseApp() {}

 public void destroyApp(boolean unconditional) {}

 public void commandAction(Command c, Displayable s) {
	if (c == exit) {	
		destroyApp(false);
		notifyDestroyed();
 	} else { 
	 	if (c == wav)
			playWav();
			
		if (c == nota)
			playNota();
			
		if (c == secuencia)
			playSecuencia();
	}
 }

	
 public void playWav() {
	try {
		// Abrir corriente de datos del archivo de sonido
		InputStream in = getClass().getResourceAsStream("/explosion.wav");
		Player p = Manager.createPlayer(in, "audio/x-wav");
		
		// comenzar reproducci�n
		p.start();
		
 	} catch (Exception e) {
		Alert alr = new Alert("Error", "No se pudo reproducir el sonido.", null, AlertType.ERROR);
		alr.setTimeout(Alert.FOREVER);
		display.setCurrent(alr, formulario);
	}
 }
 
 
 public void playNota() {
   try {
	 // reproducir nota
     Manager.playTone(ToneControl.C4, 100, 80);
   } catch (Exception e){}
 }

 
 public void playSecuencia() {
   byte tempo = 30;
   byte d = 8;

   // Creamos las notas a partir del Do central
   byte C4 = ToneControl.C4;;
   byte D4 = (byte)(C4 + 2);
   byte E4 = (byte)(C4 + 4);
   byte F4 = (byte)(C4 + 5);
   byte G4 = (byte)(C4 + 7);
   byte silencio = ToneControl.SILENCE;

   byte[] secuencia = {
    ToneControl.VERSION, 1,
    ToneControl.TEMPO, tempo,
    
    // comienzo del bloque 0
    ToneControl.BLOCK_START, 0, 
    
    // notas del bloque 0
    C4,d, F4,d, F4,d, C4,d, F4,d, F4,d, C4,d, F4,d,
    
    // fin del bloque 0
    ToneControl.BLOCK_END, 0,   
    
    // inicio del bloque 1
    ToneControl.BLOCK_START, 1,  
    
    // notas del bloque 1
    C4,d, E4,d, E4,d, C4,d, E4,d, E4,d, C4,d, E4,d,
    
    // fin del bloque 1
    ToneControl.BLOCK_END, 1,   
    
    // reproducir bloque 0
    ToneControl.PLAY_BLOCK, 0,  
    
    // reproducir bloque 1
    ToneControl.PLAY_BLOCK, 1,  
    
    // reproducir bloque 0
    ToneControl.PLAY_BLOCK, 0,  
   };

   try{
    Player p = Manager.createPlayer(Manager.TONE_DEVICE_LOCATOR);
    p.realize();
    ToneControl c = (ToneControl)p.getControl("ToneControl");
    c.setSequence(secuencia);
    p.start();
   } catch (IOException ioe) {
   } catch (MediaException me) {}
 }
}
