import java.io.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;


public class Conexion extends MIDlet {

    private Display display;

    // Url que vamos a consultar
    String url = "http://backends.barrapunto.com/barrapunto.xml";

	public Conexion() {
       display = Display.getDisplay(this);
    }

    public void startApp() {
		try {
        	verNoticias(url);
		} catch (IOException e) {}
	}

    public void pauseApp() {}

    public void destroyApp(boolean unconditional) {}

    void verNoticias(String url) throws IOException {
        HttpConnection c = null;
        InputStream is = null;
        StringBuffer b = new StringBuffer();
        StringBuffer salida = new StringBuffer();
        TextBox t = null;
       
        try {
          c = (HttpConnection)Connector.open(url);
          c.setRequestMethod(HttpConnection.GET);
          c.setRequestProperty("IF-Modified-Since", "10 Nov 2000 17:29:12 GMT");
          c.setRequestProperty("User-Agent","Profile/MIDP-1.0 Configuration/CLDC-1.0");
          c.setRequestProperty("Content-Language", "es-ES");
          is = c.openInputStream();
          int ch, i, j;

          // leer los datos de la URL
          while ((ch = is.read()) != -1) {
            b.append((char) ch);
            if (ch == '\n') {
	            if (b.toString().indexOf("<title>") > 0) {
		            i = b.toString().indexOf("<title>")+7;
		            j = b.toString().indexOf("</title>");
		        	salida.append(b.toString().substring(i,j));    
		        	salida.append("\n-------------------\n");
	            }
	        	b.delete(0,b.length());	   
            }
          }

          // mostrar noticias en la pantalla
          t = new TextBox("Noticias en barrapunto.com", salida.toString(), 1024, 0);
        } finally {
           if(is!= null) {
              is.close();
           }
           if(c != null) {
              c.close();
           }
        }
        display.setCurrent(t);
    }     
}
