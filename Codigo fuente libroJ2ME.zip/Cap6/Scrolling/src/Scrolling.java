import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Scrolling extends MIDlet implements CommandListener {

 private Command exitCommand;
 private Display display;
 private SSCanvas screen;

 public Scrolling() {
	display=Display.getDisplay(this);
	exitCommand = new Command("Salir",Command.SCREEN,2);

	screen=new SSCanvas();

	screen.addCommand(exitCommand);
	screen.setCommandListener(this);
	
	new Thread(screen).start();
 }

 public void startApp() throws MIDletStateChangeException {
	display.setCurrent(screen);
 }

 public void pauseApp() {}

 public void destroyApp(boolean unconditional) {}

 public void commandAction(Command c, Displayable s) {

	if (c == exitCommand) {
		destroyApp(false);
		notifyDestroyed();
	}
 }

}


class SSCanvas extends Canvas implements Runnable {

 private int indice_in, indice, xTiles, yTiles, sleepTime;
 private int deltaX,deltaY;
 private Sprite hero=new Sprite(1);
 private Sprite[] tile=new Sprite[5];

 // Mapa del juego
 int map[] ={	1,1,1,1,1,1,1,
 				1,1,1,1,1,1,1,
 				1,2,1,1,1,1,1,
				1,1,1,4,1,1,1,
				1,1,1,1,1,1,1,
				1,1,3,1,2,1,1,
				1,1,1,1,1,1,1,
				1,4,1,1,1,1,1,
				1,1,1,1,3,1,1,
				1,1,1,1,1,1,1,
				1,4,1,1,1,1,1,
				1,1,1,3,1,1,1,
				1,1,1,1,1,1,1,
 				1,1,1,1,1,1,1,
 				1,2,1,1,1,1,1,
				1,1,1,4,1,1,1,
				1,1,1,1,1,1,1,
				1,1,3,1,2,1,1,
				1,1,1,1,1,1,1,
				1,4,1,1,1,1,1};


 public SSCanvas() {
	// Cargamos los sprites
	hero.addFrame(1,"/hero.png");

	// Iniciamos los Sprites
	hero.on();
 }

 void iniciar() {

 int i;
	 
	sleepTime = 50;
	hero.setX(getWidth()/2);
	hero.setY(getHeight()-20);
	deltaX=0;
	deltaY=0;
	xTiles=7;
	yTiles=8;
	indice=map.length-(xTiles*yTiles);
	indice_in=0;


	// Inicializamos los tiles
	for (i=1 ; i<=4 ; i++) {
		tile[i]=new Sprite(1);
		tile[i].on();
	}

	tile[1].addFrame(1,"/tile1.png");
	tile[2].addFrame(1,"/tile2.png");
	tile[3].addFrame(1,"/tile3.png");
	tile[4].addFrame(1,"/tile4.png");
 }


 void doScroll() {

	// movimiento del scenario (scroll)
	indice_in+=2;
	if (indice_in>=32) {
		indice_in=0;
		indice-=xTiles;
	}

	if (indice <= 0) {
		// si llegamos al final, empezamos de nuevo.
		indice=map.length-(xTiles*yTiles);
		indice_in=0;
	}
 }


 void computePlayer() {
	 // actualizar posici�n del avi�n
	 if (hero.getX()+deltaX>0 && hero.getX()+deltaX<getWidth() && hero.getY()+deltaY>0 && hero.getY()+deltaY<getHeight()) {
	 	hero.setX(hero.getX()+deltaX);
	 	hero.setY(hero.getY()+deltaY);
 	}
 }


 public void run() {
	iniciar();
	 
 	while (true) {

	 	// Actualizar fondo de pantalla
	 	doScroll();

	 	// Actualizar posici�n del jugador
	 	computePlayer();

		// Actualizar pantalla
		repaint();
		serviceRepaints();

		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			System.out.println(e.toString());
		}
	}

 }


 public void keyReleased(int keyCode) {
	int action=getGameAction(keyCode);

	switch (action) {

		case LEFT:
			deltaX=0;
			break;
		case RIGHT:
			deltaX=0;
			break;
		case UP:
			deltaY=0;
			break;
		case DOWN:
			deltaY=0;
  			break;
	}
 }


 public void keyPressed(int keyCode) {

	int action=getGameAction(keyCode);

	switch (action) {

		case LEFT:
			deltaX=-5;
			break;
		case RIGHT:
			deltaX=5;
			break;
		case UP:
			deltaY=-5;
			break;
		case DOWN:
			deltaY=5;
  			break;
	}
 }

 public void paint(Graphics g) {

	int x=0,y=0,t=0;
	int i,j;

	g.setColor(255,255,255);
	g.fillRect(0,0,getWidth(),getHeight());
	g.setColor(200,200,0);

	// Dibujar fondo
	for (i=0 ; i<yTiles ; i++) {
		for (j=0 ; j<xTiles ; j++) {
			t=map[indice+(i*xTiles+j)];
			// calculo de la posici�n del tile
			x=j*32;
			y=(i-1)*32+indice_in;

			// dibujamos el tile
			tile[t].setX(x);
			tile[t].setY(y);
			tile[t].draw(g);
		}
	}

	// Dibujar el jugador
	hero.setX(hero.getX());
	hero.setY(hero.getY());
	hero.draw(g);
 }

}
