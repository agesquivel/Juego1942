import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class UI extends MIDlet implements CommandListener {
	private Command exitCommand;
	private Display display;
	private Form screen;
	
	public UI() {
		String[] estados = {"Casado","Soltero","Divorciado","Viudo"};
		
		// Obtenemos el objeto Display del midlet.
		display = Display.getDisplay(this);
		
		//  Creamos el comando Salir.
		exitCommand = new Command("Salir", Command.EXIT,2);
		
		// Creamos la pantalla principal (un formulario)
		screen = new Form("Interfaz de usuario");
		
		// Creamos y a�adimos los elemento que vamos a utilizar
		TextField nombre = new TextField("Nombre","",30,TextField.ANY);
		DateField fecha_nac = new DateField("Fecha de nacimiento", DateField.DATE);
		ChoiceGroup estado = new ChoiceGroup("Estado",List.EXCLUSIVE,estados,null);
		screen.append(nombre);
		screen.append(fecha_nac);
		screen.append(estado);
		
		
		// A�adimos el comando Salir e indicamos que clase lo manejar�
		screen.addCommand(exitCommand);
		screen.setCommandListener(this);	
	}	

	public void startApp() throws MIDletStateChangeException {
		// Seleccionamos la pantalla a mostrar
		display.setCurrent(screen);	
	}
	
	public void pauseApp() {
	}
	
	public void destroyApp(boolean incondicional) {
	}
	
	public void commandAction(Command c, Displayable s) {
		// Salir
		if (c == exitCommand) {
			destroyApp(false);
			notifyDestroyed();	
		}	
	}
}
