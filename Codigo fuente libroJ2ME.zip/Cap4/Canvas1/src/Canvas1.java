import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Canvas1 extends MIDlet implements CommandListener {

 private Command exitCommand;
 private Display display;
 private SSCanvas screen;

 public Canvas1() {
	display=Display.getDisplay(this);
	exitCommand = new Command("Salir",Command.SCREEN,2);

	screen=new SSCanvas();
	screen.addCommand(exitCommand);
	screen.setCommandListener(this);
 }
 
 public void startApp() throws MIDletStateChangeException {
	display.setCurrent(screen);
 }

 public void pauseApp() {}

 public void destroyApp(boolean unconditional) {}

 public void commandAction(Command c, Displayable s) {

	if (c == exitCommand) {
		destroyApp(false);
		notifyDestroyed();
	}

 }
 
}

class SSCanvas extends Canvas {

 public void paint(Graphics g) {

	g.setColor(255,255,255);
	g.fillRect (0, 0, getWidth(), getHeight());

	g.setColor(10,200,100);
    g.drawLine (0, 0, 100, 100);
    g.fillRect (50, 50, 30, 30);	
 }
}
